// Program.cs

using System;
using GoudEngine;

public class Program
{
    static void Main(string[] args)
    {
        using EngineConfig config = new EngineConfig();
        config
            .SetSize(
                GameConstants.ScreenWidth,
                GameConstants.ScreenHeight + (uint)GameConstants.BaseHeight
            )
            .SetTitle("Flappy Bird Clone")
            .SetPhysicsBackend2D(PhysicsBackend2D.Simple);

        using GoudGame game = config.Build();

        GameManager gameManager = new GameManager(game);

        // Initialize
        gameManager.Initialize();
        gameManager.Start();

        // Game loop - immediate-mode rendering
        while (!game.ShouldClose())
        {
            // Begin frame (poll events, clear screen)
            game.BeginFrame(0.4f, 0.7f, 0.9f, 1.0f); // Sky blue background

            // Update game logic and draw everything
            gameManager.Update(game.DeltaTime);

            // End frame (present to screen)
            game.EndFrame();
        }

        // Dispose is called automatically via 'using'
    }
}
